import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft, Briefcase, Check, CheckCircle2, Copy, Download, FileAudio,
  FileText, History, LayoutDashboard, Loader2, Mic, Pause, Play, Plus,
  Save, Search, Sparkles, StopCircle, Trash2, Upload, Users, X
} from 'lucide-react';
import jsPDF from 'jspdf';
import { AppView, Note, ProcessingStatus, SummaryFormat } from './types';
import { transcribeAudio, summarizeText } from './services/ai';
import { saveAudioLocal, getAudioLocal, deleteAudioLocal } from './services/storage';
import { Button } from './components/Button';
import { NoteCard } from './components/NoteCard';
import { Waveform } from './components/Waveform';

const Logo = () => (
  <div className="flex items-center gap-3">
    <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-700 flex items-center justify-center shadow-lg shadow-blue-500/30">
      <Briefcase className="w-6 h-6 text-white" aria-hidden="true" />
    </div>
    <div className="flex flex-col -space-y-1">
      <span className="text-xl font-black tracking-tighter text-white">Transcribe<span className="text-blue-400">App</span></span>
      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest italic">Inteligência Executiva</span>
    </div>
  </div>
);

const App: React.FC = () => {
  const [view, setView] = useState<AppView>(AppView.LIST);
  const [notes, setNotes] = useState<Note[]>([]);
  const [activeNote, setActiveNote] = useState<Note | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<SummaryFormat>(SummaryFormat.EXECUTIVE);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus>(ProcessingStatus.IDLE);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wakeLockRef = useRef<any>(null);
  const [activeStream, setActiveStream] = useState<MediaStream | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      const saved = localStorage.getItem('transcribeapp_data');
      if (!saved) return;
      try {
        const parsedNotes: Note[] = JSON.parse(saved);
        const notesWithAudio = await Promise.all(parsedNotes.map(async (note) => {
          const blob = await getAudioLocal(note.id);
          return blob ? { ...note, audioUrl: URL.createObjectURL(blob) } : note;
        }));
        setNotes(notesWithAudio);
      } catch (e) {
        console.error(e);
        setErrorMessage('Não foi possível carregar suas análises salvas neste dispositivo.');
      }
    };
    loadData();
  }, []);

  useEffect(() => {
    const notesToSave = notes.map(({ audioUrl, ...rest }) => rest);
    localStorage.setItem('transcribeapp_data', JSON.stringify(notesToSave));
  }, [notes]);

  const requestWakeLock = async () => {
    if ('wakeLock' in navigator) {
      try { wakeLockRef.current = await (navigator as any).wakeLock.request('screen'); } catch (_) { /* opcional */ }
    }
  };

  const releaseWakeLock = () => {
    if (wakeLockRef.current) {
      wakeLockRef.current.release();
      wakeLockRef.current = null;
    }
  };

  const formatTime = (seconds: number) => `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;

  const openRecording = async () => {
    setErrorMessage(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setErrorMessage('A gravação precisa de um navegador compatível e de uma conexão segura (HTTPS).');
      return;
    }
    if (typeof MediaRecorder === 'undefined') {
      setErrorMessage('Seu navegador não oferece suporte à gravação de áudio. Tente usar Chrome, Edge ou Safari atualizado.');
      return;
    }

    try {
      await requestWakeLock();
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : MediaRecorder.isTypeSupported('audio/ogg') ? 'audio/ogg' : 'audio/mp4';
      const mediaRecorder = new MediaRecorder(stream, { mimeType, audioBitsPerSecond: 128000 });
      setActiveStream(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];
      mediaRecorder.ondataavailable = (event) => { if (event.data.size > 0) audioChunksRef.current.push(event.data); };
      mediaRecorder.start(1000);
      setIsRecording(true);
      setRecordingDuration(0);
      setView(AppView.RECORD);
      timerRef.current = window.setInterval(() => setRecordingDuration((previous) => previous + 1), 1000);
    } catch (err: any) {
      console.error('Erro ao iniciar gravação:', err);
      releaseWakeLock();
      setErrorMessage(err?.name === 'NotAllowedError' ? 'Permita o acesso ao microfone nas configurações do navegador para iniciar a gravação.' : `Não foi possível acessar o microfone: ${err?.message || 'permissão negada'}.`);
    }
  };

  const cleanupRecording = () => {
    if (mediaRecorderRef.current) {
      if (mediaRecorderRef.current.state !== 'inactive') mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach((track) => track.stop());
    }
    setActiveStream(null);
    setIsRecording(false);
    releaseWakeLock();
    if (timerRef.current) window.clearInterval(timerRef.current);
  };

  const processAudio = async (blob: Blob, audioUrl: string, durationSec: number, title?: string) => {
    const noteId = Date.now().toString();
    setErrorMessage(null);
    setProcessingStatus(ProcessingStatus.TRANSCRIBING);
    setView(AppView.RECORD);
    try {
      await saveAudioLocal(noteId, blob);
      const transcription = await transcribeAudio(blob);
      setProcessingStatus(ProcessingStatus.SUMMARIZING);
      const summary = await summarizeText(transcription, selectedFormat);
      const newNote: Note = {
        id: noteId,
        title: title || `Análise ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`,
        date: new Date().toLocaleDateString('pt-BR'),
        durationFormatted: durationSec > 0 ? formatTime(durationSec) : 'Importado',
        transcription,
        summary,
        format: selectedFormat,
        tags: [],
        audioUrl
      };
      setActiveNote(newNote);
      setView(AppView.EDIT);
    } catch (error: any) {
      setErrorMessage(`Falha no processamento: ${error?.message || 'tente novamente em instantes.'}`);
      setView(AppView.LIST);
    } finally {
      setProcessingStatus(ProcessingStatus.IDLE);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const stopRecording = () => {
    if (!mediaRecorderRef.current || !isRecording) return;
    mediaRecorderRef.current.onstop = async () => {
      const mimeType = mediaRecorderRef.current?.mimeType || 'audio/webm';
      const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
      await processAudio(audioBlob, URL.createObjectURL(audioBlob), recordingDuration);
    };
    cleanupRecording();
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const maxSize = 200 * 1024 * 1024;
    if (file.size > maxSize) {
      setErrorMessage('O arquivo excede o limite de 200 MB. Comprima o áudio ou escolha um arquivo menor.');
      event.target.value = '';
      return;
    }
    setErrorMessage(null);
    const audioUrl = URL.createObjectURL(file);
    await processAudio(file, audioUrl, 0, file.name.replace(/\.[^/.]+$/, ''));
  };

  const deleteNote = async (id: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    if (!window.confirm('Excluir esta nota e o áudio associado? Essa ação não pode ser desfeita.')) return;
    await deleteAudioLocal(id);
    setNotes((previous) => previous.filter((note) => note.id !== id));
    if (activeNote?.id === id) setView(AppView.LIST);
  };

  const saveNote = () => {
    if (!activeNote) return;
    setNotes((previous) => previous.find((note) => note.id === activeNote.id) ? previous.map((note) => note.id === activeNote.id ? activeNote : note) : [activeNote, ...previous]);
    setNotice('Análise salva neste dispositivo.');
    window.setTimeout(() => setNotice(null), 2500);
    setView(AppView.LIST);
  };

  const copyText = async (key: string, text: string) => {
    await navigator.clipboard.writeText(text);
    setCopiedSection(key);
    window.setTimeout(() => setCopiedSection(null), 2000);
  };

  const exportPdf = () => {
    if (!activeNote) return;
    const pdf = new jsPDF();
    const lines = pdf.splitTextToSize(`${activeNote.title}\n\n${activeNote.summary}\n\nTranscrição Bruta\n${activeNote.transcription}`, 175);
    pdf.setFontSize(16);
    pdf.text(activeNote.title, 18, 20);
    pdf.setFontSize(10);
    pdf.text(lines.slice(2), 18, 32);
    pdf.save(`${activeNote.title.replace(/[^a-z0-9À-ÿ]+/gi, '-').toLowerCase() || 'analise'}.pdf`);
    setNotice('PDF exportado com sucesso.');
    window.setTimeout(() => setNotice(null), 2500);
  };

  const filteredNotes = notes.filter((note) => `${note.title} ${note.summary} ${note.transcription}`.toLowerCase().includes(searchQuery.toLowerCase()));

  if (view === AppView.RECORD) {
    return (
      <div className="h-full bg-slate-950 flex flex-col items-center justify-center p-8 safe-top safe-bottom relative overflow-hidden">
        {processingStatus === ProcessingStatus.IDLE && (
          <button aria-label="Cancelar gravação" title="Cancelar gravação" onClick={() => { cleanupRecording(); setView(AppView.LIST); }} className="absolute top-10 left-8 p-4 bg-slate-900/70 rounded-2xl text-slate-400 hover:text-white focus-visible:ring-2 focus-visible:ring-blue-400">
            <X className="w-6 h-6" aria-hidden="true" />
          </button>
        )}
        <div className="w-full max-w-md flex flex-col items-center gap-10">
          {processingStatus !== ProcessingStatus.IDLE ? (
            <div className="flex flex-col items-center gap-8 text-center" role="status" aria-live="polite">
              <Loader2 className="w-24 h-24 text-blue-400 animate-spin" aria-hidden="true" />
              <div className="space-y-4">
                <p className="text-3xl font-black text-white">Processando sua análise</p>
                <p className="text-slate-400">{processingStatus === ProcessingStatus.TRANSCRIBING ? 'Transcrevendo o áudio…' : 'Gerando o formato escolhido…'}</p>
                <div className="bg-slate-900/70 px-5 py-2 rounded-full border border-blue-500/20 text-blue-400 font-bold uppercase text-xs tracking-widest">Isso pode levar alguns instantes</div>
              </div>
            </div>
          ) : (
            <>
              <div className="relative" aria-hidden="true">
                <div className="absolute inset-0 bg-red-500/10 blur-3xl rounded-full animate-pulse scale-[1.8]" />
                <div className="w-64 h-64 rounded-full bg-slate-900/30 border-[6px] border-red-500/10 flex items-center justify-center relative z-10"><Mic className="w-24 h-24 text-red-500" /></div>
              </div>
              <div className="flex flex-col items-center gap-8 w-full">
                <div className="space-y-2 text-center"><span className="text-8xl font-mono font-black text-white tracking-tighter tabular-nums block">{formatTime(recordingDuration)}</span><p className="text-red-500 font-black uppercase tracking-[0.4em] text-[10px]">Gravando</p></div>
                <Waveform isRecording={isRecording} stream={activeStream} />
                <button onClick={stopRecording} className="mt-6 w-full h-20 bg-gradient-to-r from-red-600 to-rose-700 text-white rounded-[28px] font-black text-xl flex items-center justify-center gap-4 shadow-2xl active:scale-95 focus-visible:ring-2 focus-visible:ring-red-300"><StopCircle className="w-7 h-7" aria-hidden="true" /> Parar e processar</button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  if (view === AppView.EDIT && activeNote) {
    return (
      <div className="h-full bg-slate-950 flex flex-col safe-top safe-bottom">
        <header className="px-4 py-6 flex items-center gap-3 border-b border-slate-900/50 backdrop-blur-md sticky top-0 z-50">
          <button aria-label="Voltar para análises" title="Voltar" onClick={() => setView(AppView.LIST)} className="p-3 bg-slate-900 rounded-xl text-slate-400 focus-visible:ring-2 focus-visible:ring-blue-400"><ArrowLeft className="w-5 h-5" aria-hidden="true" /></button>
          <input aria-label="Título da análise" value={activeNote.title} onChange={(event) => setActiveNote({ ...activeNote, title: event.target.value })} className="flex-1 min-w-0 bg-transparent border-none text-xl font-black outline-none text-white focus:ring-2 focus:ring-blue-500/30 rounded-lg px-2" />
          <button aria-label="Exportar análise em PDF" title="Exportar PDF" onClick={exportPdf} className="p-3 text-slate-400 hover:text-blue-400 focus-visible:ring-2 focus-visible:ring-blue-400"><Download className="w-5 h-5" aria-hidden="true" /></button>
          <button aria-label="Excluir análise" title="Excluir análise" onClick={() => deleteNote(activeNote.id)} className="p-3 text-slate-600 hover:text-red-500 focus-visible:ring-2 focus-visible:ring-red-400"><Trash2 className="w-5 h-5" aria-hidden="true" /></button>
        </header>
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-40 scrollbar-hide">
          {activeNote.audioUrl && <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl flex items-center gap-5"><button aria-label={isPlaying ? 'Pausar áudio' : 'Reproduzir áudio'} title={isPlaying ? 'Pausar áudio' : 'Reproduzir áudio'} onClick={() => { if (audioRef.current) isPlaying ? audioRef.current.pause() : audioRef.current.play(); setIsPlaying(!isPlaying); }} className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-lg focus-visible:ring-2 focus-visible:ring-blue-300">{isPlaying ? <Pause className="w-7 h-7" aria-hidden="true" /> : <Play className="w-7 h-7 fill-current ml-1" aria-hidden="true" />}</button><div className="flex-1"><div className="text-[10px] text-slate-500 uppercase font-black tracking-widest mb-1">Playback de áudio</div><div className="text-base font-bold text-slate-100">{activeNote.durationFormatted}</div></div><audio ref={audioRef} src={activeNote.audioUrl} onEnded={() => setIsPlaying(false)} /></div>}
          <section className="bg-slate-900/40 p-6 rounded-[32px] border border-slate-800/50 space-y-5"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-blue-400" aria-hidden="true" /><h2 className="text-slate-100 text-sm font-bold">{activeNote.format === SummaryFormat.EXECUTIVE ? 'Resumo Executivo' : 'Ata de Reunião Formal'}</h2></div><button aria-label="Copiar resumo" title="Copiar resumo" onClick={() => copyText('s', activeNote.summary)} className="text-slate-400 p-2 bg-slate-800 rounded-lg focus-visible:ring-2 focus-visible:ring-blue-400">{copiedSection === 's' ? <Check className="w-4 h-4 text-green-500" aria-hidden="true" /> : <Copy className="w-4 h-4" aria-hidden="true" />}</button></div><textarea aria-label="Resumo editável" value={activeNote.summary} onChange={(event) => setActiveNote({ ...activeNote, summary: event.target.value })} className="w-full h-80 bg-transparent text-slate-300 leading-relaxed outline-none resize-y text-sm font-medium scrollbar-hide" /></section>
          <section className="bg-slate-900/20 p-6 rounded-[32px] border border-slate-900 space-y-5"><div className="flex items-center justify-between"><h2 className="text-slate-300 text-sm font-bold">Transcrição bruta</h2><button aria-label="Copiar transcrição" title="Copiar transcrição" onClick={() => copyText('t', activeNote.transcription)} className="text-slate-400 p-2 focus-visible:ring-2 focus-visible:ring-blue-400">{copiedSection === 't' ? <Check className="w-4 h-4 text-green-500" aria-hidden="true" /> : <Copy className="w-4 h-4" aria-hidden="true" />}</button></div><textarea aria-label="Transcrição editável" value={activeNote.transcription} onChange={(event) => setActiveNote({ ...activeNote, transcription: event.target.value })} className="w-full h-64 bg-transparent text-slate-400 text-sm leading-relaxed outline-none resize-y" /></section>
        </div>
        <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-slate-950 via-slate-950/95 to-transparent safe-bottom z-50"><Button variant="primary" onClick={saveNote} className="w-full bg-blue-600 py-5 rounded-2xl shadow-xl shadow-blue-500/20 text-lg font-black"><Save className="w-5 h-5" aria-hidden="true" /> Salvar análise</Button></div>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-950 flex flex-col overflow-hidden safe-top safe-bottom">
      <header className="p-6 space-y-6">
        <div className="flex justify-between items-center"><Logo /><div className="flex items-center gap-3"><button aria-label="Histórico de análises" title="Histórico de análises" onClick={() => document.getElementById('analises')?.scrollIntoView({ behavior: 'smooth' })} className="p-3 bg-slate-900/50 rounded-2xl text-slate-400 focus-visible:ring-2 focus-visible:ring-blue-400"><History className="w-5 h-5" aria-hidden="true" /></button><div aria-label="Perfil AD" className="w-11 h-11 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 font-bold border border-slate-700">AD</div></div></div>
        <div className="flex p-1.5 bg-slate-900/50 rounded-2xl border border-slate-800" role="tablist" aria-label="Formato da análise"><button role="tab" aria-selected={selectedFormat === SummaryFormat.EXECUTIVE} onClick={() => setSelectedFormat(SummaryFormat.EXECUTIVE)} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all font-bold text-xs uppercase tracking-widest ${selectedFormat === SummaryFormat.EXECUTIVE ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><LayoutDashboard className="w-4 h-4" aria-hidden="true" /> Resumo executivo</button><button role="tab" aria-selected={selectedFormat === SummaryFormat.MEETING_MINUTES} onClick={() => setSelectedFormat(SummaryFormat.MEETING_MINUTES)} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl transition-all font-bold text-xs uppercase tracking-widest ${selectedFormat === SummaryFormat.MEETING_MINUTES ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400'}`}><FileText className="w-4 h-4" aria-hidden="true" /> Ata de reunião</button></div>
        <div className="relative group"><Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" aria-hidden="true" /><input aria-label="Pesquisar análises por título, resumo ou transcrição" placeholder="Pesquisar análises…" value={searchQuery} onChange={(event) => setSearchQuery(event.target.value)} className="w-full bg-slate-900/40 border border-slate-800/50 rounded-[20px] py-4 pl-12 pr-4 text-sm focus:border-blue-500/50 outline-none transition-all text-white backdrop-blur-sm" /></div>
      </header>
      <div id="analises" className="flex-1 overflow-y-auto px-6 space-y-4 pb-44 scrollbar-hide">
        {filteredNotes.length === 0 ? <div className="flex flex-col items-center justify-center min-h-[45vh] text-center gap-5"><div className="p-8 bg-slate-900/30 rounded-[40px] border border-slate-800/50"><FileAudio className="w-14 h-14 text-slate-600" aria-hidden="true" /></div><div><h1 className="text-xl font-bold text-slate-200">Sua próxima reunião começa aqui</h1><p className="text-sm leading-relaxed text-slate-400 mt-2 max-w-sm">Grave ou envie um áudio para transformar a conversa em resumo, decisões e próximos passos.</p></div><div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm"><button onClick={openRecording} className="flex-1 px-5 py-4 rounded-2xl bg-blue-600 text-white font-bold flex items-center justify-center gap-2 focus-visible:ring-2 focus-visible:ring-blue-300"><Mic className="w-5 h-5" aria-hidden="true" /> Gravar reunião</button><button onClick={() => fileInputRef.current?.click()} className="flex-1 px-5 py-4 rounded-2xl bg-slate-800 border border-slate-700 text-slate-200 font-bold flex items-center justify-center gap-2 focus-visible:ring-2 focus-visible:ring-blue-300"><Upload className="w-5 h-5" aria-hidden="true" /> Enviar áudio</button></div><p className="text-xs text-slate-500">MP3, WAV, M4A ou WebM · até 200 MB</p></div> : filteredNotes.map((note) => <NoteCard key={note.id} note={note} onClick={() => { setActiveNote(note); setView(AppView.EDIT); }} onDelete={(event) => deleteNote(note.id, event)} />)}
      </div>
      <div className="fixed bottom-6 right-6 flex flex-col gap-3 z-50"><input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="audio/mpeg,audio/wav,audio/x-m4a,audio/mp4,audio/webm,audio/ogg,audio/*" className="sr-only" aria-label="Selecionar arquivo de áudio" /><button onClick={() => fileInputRef.current?.click()} aria-label="Enviar arquivo de áudio" title="Enviar arquivo de áudio" className="h-14 w-14 bg-slate-800 rounded-2xl shadow-xl flex items-center justify-center text-slate-200 border border-slate-700 focus-visible:ring-2 focus-visible:ring-blue-300"><Upload className="w-6 h-6" aria-hidden="true" /></button><button onClick={openRecording} aria-label="Gravar nova reunião" title="Gravar nova reunião" className="h-18 w-18 p-5 bg-gradient-to-br from-blue-400 to-blue-700 rounded-[24px] shadow-2xl shadow-blue-500/40 flex items-center justify-center text-white focus-visible:ring-2 focus-visible:ring-blue-300"><Plus className="w-9 h-9" aria-hidden="true" /></button></div>
      {(errorMessage || notice) && <div className={`fixed bottom-5 left-5 right-24 sm:left-1/2 sm:right-auto sm:-translate-x-1/2 max-w-xl z-[60] rounded-2xl border px-4 py-3 text-sm shadow-2xl ${errorMessage ? 'bg-red-950/95 border-red-700 text-red-100' : 'bg-emerald-950/95 border-emerald-700 text-emerald-100'}`} role="status" aria-live="polite">{errorMessage ? <div className="flex items-start gap-3"><span className="flex-1">{errorMessage}</span><button aria-label="Fechar mensagem" onClick={() => setErrorMessage(null)}><X className="w-4 h-4" /></button></div> : <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4" aria-hidden="true" />{notice}</div>}</div>}
      <p className="fixed bottom-1 left-5 text-[10px] text-slate-600">Seus áudios ficam salvos localmente neste dispositivo.</p>
    </div>
  );
};

export default App;
